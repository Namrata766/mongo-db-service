package com.prakhar.mongo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.prakhar.mongo.entity.User;
import com.prakhar.mongo.service.UserService;

@RestController
public class UserController {
	
	@Autowired
	UserService userService;
	
	@GetMapping(value = "/getAll", produces = "application/json")
	public List<User> getAll() {
		return userService.getAllUsers();
	}

	@GetMapping(value = "/getUserById/{id}", produces = "application/json")
	public User getUserById(@PathVariable String id) {
		
		return userService.getUserById(id);
	}
	
	@GetMapping(value = "/getUserByName/{name}", produces = "application/json")
	public List<User> getUserByName(@PathVariable String name) {
		
		return userService.getUserByName(name);
	}
	
	@GetMapping(value = "/getUserCountByName/{name}", produces = "application/json")
	public String getUserCountByName(@PathVariable String name) {
		
		List<User> usersFound =  userService.getUserByName(name);
		return "Number of occurrences of User name " + name + " is "
				+ usersFound.size() + " in the all the documents.";
	}
	
	@PostMapping(value = "/createUser", produces = "application/json")
	public User createUser(@RequestBody User user) {
		
		return userService.createUser(user);
	}
	
	@PostMapping(value = "/createUsers", produces = "application/json")
	public List<User> createUsers(@RequestBody List<User> users) {
		
		List<User> usersCreated = new ArrayList<>();
		
		users.forEach(u -> {
			User newUser = userService.createUser(u);
			usersCreated.add(newUser);
		});
		
		return usersCreated;
	}
}