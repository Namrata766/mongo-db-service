package com.prakhar.mongo.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Component;

import com.prakhar.mongo.entity.User;

@Component
public interface UserRepository extends MongoRepository<User, String>{

	@Query("{userName : ?0}")
	public List<User> getUserByName(String name);

}